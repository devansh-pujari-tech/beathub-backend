Title= Beathub-Backend

run seed.js file by using command node scripts/seed.js
