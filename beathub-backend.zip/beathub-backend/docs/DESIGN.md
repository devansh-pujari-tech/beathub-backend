Q> Why did you reference Songs in the Playlist instead of embedding them?
answer: Songs are referenced in playlists to prevent duplication and allow reuse across multiple playlists.

Q> Why did you reference the Artist in the Song model?
answer: Artists are referenced in songs to maintain a one-to-many relationship and ensure a single source of truth for artist data.
